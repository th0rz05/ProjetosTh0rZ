# DA_Project
#1 Project of DA

Colocar a pasta database com as encomendas e carrinhas dentro da pasta 
cmake-build-debug no CLION

