var searchData=
[
  ['setcarga_0',['setCarga',['../class_carrinha.html#afcd64b2f03559f52ac872a48c85a912f',1,'Carrinha']]],
  ['setcarrinhas_1',['setCarrinhas',['../class_empresa.html#a9be60f9b0f4514d12e2ba482563a00eb',1,'Empresa']]],
  ['setcusto_2',['setCusto',['../class_carrinha.html#aedddb623a5dfe1a89fe1a129b3c7b71c',1,'Carrinha']]],
  ['setduracao_3',['setDuracao',['../class_encomenda.html#a9ca6d38640dcbe2e3546ef8bf3f24b17',1,'Encomenda']]],
  ['setencomendas_4',['setEncomendas',['../class_empresa.html#a57b7cf65bd6cd70c3c1cccc68465e761',1,'Empresa']]],
  ['setid_5',['setId',['../class_carrinha.html#a6364ab6a452d55cc260611af0c80d6ea',1,'Carrinha::setId()'],['../class_encomenda.html#a5d98f7bc38eb20317b3a8500991ca873',1,'Encomenda::setId(int id)']]],
  ['setpeso_6',['setPeso',['../class_encomenda.html#afa98d6d3df6c2246235226522b3ac2bb',1,'Encomenda']]],
  ['setpesomax_7',['setPesoMax',['../class_carrinha.html#a0c3d98551bf466a85b4d775fb3d6a735',1,'Carrinha']]],
  ['setrecompensa_8',['setRecompensa',['../class_encomenda.html#a6cea7774bbca121f9e6f03ff58850bb7',1,'Encomenda']]],
  ['setvolmax_9',['setVolMax',['../class_carrinha.html#aeb8439850bc8026441d238731eb57b96',1,'Carrinha']]],
  ['setvolume_10',['setVolume',['../class_encomenda.html#a4fd6c38c000144f6889aa1603e804a08',1,'Encomenda']]]
];
