var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_carrinha.html#acb45f7ba92be3d16e88458eb5f748df2',1,'Carrinha::operator&lt;&lt;()'],['../class_encomenda.html#adb7b76a20f435f82ecf0151fa7fadbad',1,'Encomenda::operator&lt;&lt;()']]],
  ['operator_3d_3d_1',['operator==',['../class_encomenda.html#afc7aebd68b1869a9ca4aa353d7ac8792',1,'Encomenda']]]
];
