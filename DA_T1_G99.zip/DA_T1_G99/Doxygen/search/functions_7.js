var searchData=
[
  ['valorcarga_0',['valorCarga',['../class_carrinha.html#a302ac93a116e07019b5cdd2af8225d41',1,'Carrinha']]]
];
