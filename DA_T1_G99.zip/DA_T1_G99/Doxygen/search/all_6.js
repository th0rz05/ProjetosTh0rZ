var searchData=
[
  ['usada_0',['usada',['../class_carrinha.html#a5d8475f472907c9557db663d41b7a397',1,'Carrinha']]]
];
