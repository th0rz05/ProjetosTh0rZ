var searchData=
[
  ['adicionarencomenda_0',['adicionarEncomenda',['../class_carrinha.html#a4ac451b1be59860518cb9c08a0724442',1,'Carrinha']]]
];
