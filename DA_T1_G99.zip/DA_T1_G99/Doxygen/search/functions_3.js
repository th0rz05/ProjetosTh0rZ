var searchData=
[
  ['gerarencomendas_0',['gerarEncomendas',['../class_empresa.html#ac4bdf98954a3e13178da3bfdb29245be',1,'Empresa']]],
  ['gerartabelacarrinhascomcarga_1',['gerarTabelaCarrinhasComCarga',['../class_empresa.html#a6660718bd443cff6701923c578c84b78',1,'Empresa']]],
  ['gerartabelaencomendasdodia_2',['gerarTabelaEncomendasDoDia',['../class_empresa.html#a67fe81e1316934007b57af73a53e1e31',1,'Empresa']]],
  ['gerartabelaencomendasexpressoentregues_3',['gerarTabelaEncomendasExpressoEntregues',['../class_empresa.html#a6aa9d8266c14b4bb76e5df03cd40f289',1,'Empresa']]],
  ['gerartabelaencomendasnaoentregues_4',['gerarTabelaEncomendasNaoEntregues',['../class_empresa.html#a562af41875fb107145baf73fc811f706',1,'Empresa']]],
  ['getcarga_5',['getCarga',['../class_carrinha.html#ab4b90bb0f480487c6cbc50b859385967',1,'Carrinha']]],
  ['getcarrinhas_6',['getCarrinhas',['../class_empresa.html#af6f43a8f6628eba4a6e38cb3a73cbd18',1,'Empresa']]],
  ['getcusto_7',['getCusto',['../class_carrinha.html#a800b496c6e35bf9251169b5608afce07',1,'Carrinha']]],
  ['getduracao_8',['getDuracao',['../class_encomenda.html#af6428ec6f25344e255682967a2e4e45a',1,'Encomenda']]],
  ['getencomendas_9',['getEncomendas',['../class_empresa.html#ad5594481ff8d3ebf87cd4b3377337966',1,'Empresa']]],
  ['getid_10',['getId',['../class_carrinha.html#a1548f9bde51129b65710b2886d84854d',1,'Carrinha::getId()'],['../class_encomenda.html#aa6dd94ea6eb3c73ae44f0e0de66c4066',1,'Encomenda::getId() const']]],
  ['getpeso_11',['getPeso',['../class_encomenda.html#a8dd1b7ab13757de77f1bb5205410a66a',1,'Encomenda']]],
  ['getpesomax_12',['getPesoMax',['../class_carrinha.html#a118786c4bf73658c00501472ca8d7cae',1,'Carrinha']]],
  ['getpesorestante_13',['getPesoRestante',['../class_carrinha.html#aefada5e5229d41b82335ead551c73067',1,'Carrinha']]],
  ['getrecompensa_14',['getRecompensa',['../class_encomenda.html#a8cada87c5c91d3af646b9ce8cd4b6eb9',1,'Encomenda']]],
  ['getvolmax_15',['getVolMax',['../class_carrinha.html#a2f7c2de6c4a29aa2a37417dc8d97023e',1,'Carrinha']]],
  ['getvolrestante_16',['getVolRestante',['../class_carrinha.html#ac3d442a8716de2bddb5b4e45cb7c41bd',1,'Carrinha']]],
  ['getvolume_17',['getVolume',['../class_encomenda.html#af1ae4ecf620739f2d2d6c5f99b26d398',1,'Encomenda']]]
];
