var searchData=
[
  ['operator_3d_3d_0',['operator==',['../class_encomenda.html#afc7aebd68b1869a9ca4aa353d7ac8792',1,'Encomenda']]]
];
